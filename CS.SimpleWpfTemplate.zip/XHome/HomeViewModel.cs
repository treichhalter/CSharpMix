﻿using Caliburn.Micro;

namespace $safeprojectname$.XHome
{
    public class HomeViewModel : Screen
    {
    }
}