﻿using System.Globalization;
using System.Windows;
using System.Windows.Markup;

namespace $safeprojectname$
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        // ********************
        // Constructor
        // ********************
        static App()
        {
            // Override US culture with local culture
            FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
                new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));
        }
    }
}