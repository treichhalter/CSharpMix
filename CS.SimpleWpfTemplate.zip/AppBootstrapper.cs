﻿using Autofac;
using Caliburn.Micro;
using $safeprojectname$.XHome;
using $safeprojectname$.XInfo;
using System;
using System.Collections.Generic;
using System.Windows;
using Autofac.log4net;

namespace $safeprojectname$
{
    public class AppBootstrapper : BootstrapperBase
    {
        private static IContainer _container;

        public AppBootstrapper()
        {
            this.Initialize();
        }

        protected override void Configure()
        {
            var builder = new ContainerBuilder();

            builder.RegisterType<WindowManager>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<EventAggregator>().AsImplementedInterfaces().SingleInstance();            
            builder.RegisterType<ShellViewModel>();            
            builder.RegisterType<HomeViewModel>();
            builder.RegisterType<InfoViewModel>();            

            var loggingModule = new Log4NetModule()
            {
                ConfigFileName =  "logger.config",
                ShouldWatchConfiguration = true
            };

           builder.RegisterModule(loggingModule);

            _container = builder.Build();            
        }

        protected override IEnumerable<object> GetAllInstances(Type service)
        {
            var type = typeof(IEnumerable<>).MakeGenericType(service);
            return _container.Resolve(type) as IEnumerable<object>;
        }

        protected override object GetInstance(Type service, string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                if (_container.IsRegistered(service))
                {
                    return _container.Resolve(service);
                }
            }
            else
            {
                if (_container.IsRegisteredWithKey(key, service))
                {
                    return _container.ResolveKeyed(key, service);
                }
            }

            const string msgFormat = "Could not locate any instances of contract {0}.";
            var msg = string.Format(msgFormat, key ?? service.Name);
            throw new Exception(msg);
        }

        protected override void BuildUp(object instance)
        {
            _container.InjectProperties(instance);
        }

        protected override void OnStartup(object sender, StartupEventArgs e)
        {
            DisplayRootViewFor<ShellViewModel>();
        }
    }
}