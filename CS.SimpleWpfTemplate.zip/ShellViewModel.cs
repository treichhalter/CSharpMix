﻿using Caliburn.Micro;
using $safeprojectname$.XHome;
using $safeprojectname$.XInfo;
using System.Windows;
using ILog = log4net.ILog;

namespace $safeprojectname$
{
    public class ShellViewModel : Conductor<object>
    {
        private Visibility _menuCloseIsVisible;
        private Visibility _menuOpenIsVisible;
        private ILog _logger;

        public ShellViewModel(log4net.ILog logger)
        {
            _logger = logger;
            MenuOpenIsVisible = Visibility.Collapsed;
            Home();
        }

        public Visibility MenuOpenIsVisible
        {
            get => _menuOpenIsVisible;
            set
            {
                _menuOpenIsVisible = value;
                NotifyOfPropertyChange(() => MenuOpenIsVisible);
            }
        }

        public Visibility MenuCloseIsVisible
        {
            get => _menuCloseIsVisible;
            set
            {
                _menuCloseIsVisible = value;
                NotifyOfPropertyChange(() => MenuCloseIsVisible);
            }
        }

        public void MenuOpen()
        {
            MenuOpenIsVisible = Visibility.Collapsed;
            MenuCloseIsVisible = Visibility.Visible;
        }

        public void MenuClose()
        {
            MenuOpenIsVisible = Visibility.Visible;
            MenuCloseIsVisible = Visibility.Collapsed;
        }

        public void Close()
        {
            System.Windows.Application.Current.Shutdown();
        }

        public void Home()
        {
            ActivateItem(IoC.Get<HomeViewModel>());
            _logger.Info("Button: " + nameof(Home));
        }

        public void Info()
        {
            ActivateItem(IoC.Get<InfoViewModel>());
            _logger.Info("Button: " + nameof(Info));
        }
    }
}