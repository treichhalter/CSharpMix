﻿using System.Deployment.Application;
using System.Reflection;
using Caliburn.Micro;

namespace $safeprojectname$.XInfo
{
    public class InfoViewModel : Screen
    {
        public InfoViewModel()
        {
            SoftwareVersion = GetSoftwareVersion;
        }

        public string SoftwareVersion { get; set; }

        private string GetSoftwareVersion
        {
            get
            {
                if (ApplicationDeployment.IsNetworkDeployed)
                {
                    var ver = ApplicationDeployment.CurrentDeployment.CurrentVersion;
                    return string.Format("Version: {0}.{1}.{2}.{3}", ver.Major, ver.Minor, ver.Build, ver.Revision,
                        Assembly.GetEntryAssembly().GetName().Name);
                }
                else
                {
                    var ver = Assembly.GetExecutingAssembly().GetName().Version;
                    return string.Format("Version: {0}.{1}.{2}.{3}", ver.Major, ver.Minor, ver.Build, ver.Revision,
                        Assembly.GetEntryAssembly().GetName().Name);
                }
            }
        }
    }
}